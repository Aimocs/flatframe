<?php

namespace Aimocs\Iis\Tests\SessionTest;

use Aimocs\Iis\Flat\Session\Session;
use PHPUnit\Framework\TestCase;

class SessionTest extends TestCase
{

    protected  function setUp(): void
    {
        unset($_SESSION);
    }

    public function testFlashFunctions():void
    {

        $session = new Session();
        $session->setFlash("success","Great JOB!");
        $session->setFlash("error","Bad JOB!");

        $this->assertTrue($session->hasFlash("success"));
        $this->assertTrue($session->hasFlash("error"));
        $this->assertEquals(["Great JOB!"],$session->getFlash("success"));
        $this->assertEquals(["Bad JOB!"], $session->getFlash("error"));
        $this->assertEquals([],$session->getFlash("warning"));
    }

}