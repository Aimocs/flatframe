<?php

namespace Aimocs\Iis\Tests\ContainerTest;

class CTDependencyClass
{

}