<?php

namespace Aimocs\Iis\Flat\Controller;

use Aimocs\Iis\Flat\Database\Database;
use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;
use Psr\Container\ContainerInterface;
abstract class AbstractController
{

    protected ?ContainerInterface $container = null;
    protected ?Database $db_connection = null;

    protected Request $request;

    public function setContainer(ContainerInterface $container): void
    {
        $this->container = $container;
        $this->setDBConnection($this->container->get(Database::class));
    }

    public function render(string $template , array $parameters , Response $response = null):Response
    {
        $content = $this->container->get('template-engine')->render($template, $parameters);

        $response ??= new Response();

        $response->setContent($content);

        return $response;
        
    }

    public function setDBConnection(Database $database):void
    {
        $this->db_connection = $database;
    }

    public function setRequest(Request $request):void
    {
        $this->request = $request;
    }

}