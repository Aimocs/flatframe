<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;
use Aimocs\Iis\Flat\Session\SessionInterface;

class StartSession implements MiddlewareInterface
{
    //for now
    private string $apiPrefix = "/api/";

    public function __construct(
        private SessionInterface $session
//        , private string $apiPrefix = '/api/'
    )
    {
    }

    public function process(Request $request, RequestHandlerInterface $requestHandler): Response
    {
        if(!str_starts_with($request->getPath(), $this->apiPrefix)){

            $this->session->start();

            $request->setSession($this->session);
        }

        return $requestHandler->handle($request);
    }
}