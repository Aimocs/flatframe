<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;

class Dummy implements MiddlewareInterface
{
    public function process(Request $request, RequestHandlerInterface $requestHandler):Response
    {
        return $requestHandler->handle($request);
    }

}