<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;
use Psr\Container\ContainerInterface;

class RequestHandler implements RequestHandlerInterface
{
    private array $middleware = [
        ExtractRouteInfo::class,
        StartSession::class,
        RouterDispatch::class
    ];

    public function __construct(private ContainerInterface $container)
    {
    }

    public function handle(Request $request): Response
    {
        if(empty($this->middleware)){
            return new Response("It's totally forked, mate. Contact Support", 500);
        }

        $middlewareClass = array_shift($this->middleware);

        $middleware= $this->container->get($middlewareClass);

        $response = $middleware->process($request,$this);

    return $response;
    }

    public function injectMiddleware(array $middleware): void
    {
        array_splice($this->middleware,0,0,$middleware);
    }
}