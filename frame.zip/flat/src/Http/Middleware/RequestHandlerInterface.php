<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;

interface RequestHandlerInterface
{
    public function handle(Request $request): Response;

}