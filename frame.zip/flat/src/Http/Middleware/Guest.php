<?php

namespace Aimocs\Iis\Flat\Http\Middleware;


use Aimocs\Iis\Flat\Http\RedirectResponse;
use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;
use Aimocs\Iis\Flat\Session\Session;
use Aimocs\Iis\Flat\Session\SessionInterface;
class Guest implements MiddlewareInterface
{
    public function __construct(private SessionInterface $session)
    {

    }
    public function process(Request $request, RequestHandlerInterface $requestHandler): Response
    {
        $this->session->start();
        if ($this->session->has(Session::AUTH_KEY)) {
            return new RedirectResponse("/dash");
        }
        return $requestHandler->handle($request);
    }
}
