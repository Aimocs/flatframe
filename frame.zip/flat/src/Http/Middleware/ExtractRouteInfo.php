<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\HttpException;
use Aimocs\Iis\Flat\Http\HttpRequestMethodException;
use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;
use Aimocs\Iis\Flat\Router\Dispatcher;
use Aimocs\Iis\Flat\Router\RouteCollector;

class ExtractRouteInfo implements MiddlewareInterface
{
    public function __construct(private array $routes)
    {
    }

    public function process(Request $request, RequestHandlerInterface $requestHandler): Response
    {
        // create a dispatcher
        $routeCollector =new  RouteCollector();
        foreach($this->routes as $route){
            $routeCollector->addRoute(...$route);
        }
        $dispatcher = new Dispatcher($routeCollector);

        // Dispatch a URI, to obtain the route info
        $routeInfo = $dispatcher->dispatch($request->getPath(),$request->getMethod());



        switch ($routeInfo[0]){
            case Dispatcher::FOUND:
                $request->setRouteHandler($routeInfo[1]);

                $request->setRouteHandlerArgs($routeInfo[2]);

                if(is_array($routeInfo[1]) && isset($routeInfo[1][2])){
                    $requestHandler->injectMiddleware($routeInfo[1][2]);
                }
                break;
            case Dispatcher::METHOD_NOT_ALLOWED:
                $e = new HttpRequestMethodException("The method is not allowed");
                $e->setStatusCode(405);
                throw $e;
            default:
                $e = new HttpException("Not Found");
                throw $e;
        }
        return $requestHandler->handle($request);
    }
}