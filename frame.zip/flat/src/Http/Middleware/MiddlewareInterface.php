<?php

namespace Aimocs\Iis\Flat\Http\Middleware;

use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;

interface MiddlewareInterface
{
    public function process(Request $request, RequestHandlerInterface $requestHandler):Response;
}