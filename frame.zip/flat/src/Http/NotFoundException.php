<?php

namespace Aimocs\Iis\Flat\Http;

class NotFoundException extends HttpException
{

}