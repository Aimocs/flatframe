<?php

namespace Aimocs\Iis\Flat\Http\Event;

use Aimocs\Iis\Flat\EventDispatcher\Event;
use Aimocs\Iis\Flat\Http\Request;
use Aimocs\Iis\Flat\Http\Response;

class ResponseEvent extends Event
{
    public function __construct(
        private Request $request,
        private Response $response
    )
    {
    }

    public function getRequest(): Request
    {
        return $this->request;
    }

    public function getResponse(): Response
    {
        return $this->response;
    }



}