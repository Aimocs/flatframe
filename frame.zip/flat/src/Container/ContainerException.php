<?php

namespace Aimocs\Iis\Flat\Container;

class ContainerException extends \Exception
{

}