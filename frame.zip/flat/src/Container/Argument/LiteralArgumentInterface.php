<?php

namespace Aimocs\Iis\Flat\Container\Argument;

interface LiteralArgumentInterface extends ArgumentInterface
{

}