<?php

namespace Aimocs\Iis\Flat\Database;

use Aimocs\Iis\Flat\Database\Event\PostPersist;
use Aimocs\Iis\Flat\EventDispatcher\EventDispatcher;
use Aimocs\Iis\Flat\Session\SessionInterface;

class DataMapper
{

    public function __construct(
        private Database $database,
        private EventDispatcher $eventDispatcher,
        private SessionInterface $session
    )
    {
    }

    public function getDatabase(): Database
    {
        return $this->database;
    }

    public function save(Entity $subject):void
    {
        //dispatch POSTPERSIST
        $this->eventDispatcher->dispatch(new PostPersist($subject,$this->session));

    }
}