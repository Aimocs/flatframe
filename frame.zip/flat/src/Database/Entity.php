<?php

namespace Aimocs\Iis\Flat\Database;

abstract class Entity
{

}