<?php

namespace Aimocs\Iis\Flat\Database\Event;


use Aimocs\Iis\Flat\Database\Entity;
use Aimocs\Iis\Flat\EventDispatcher\Event;
use Aimocs\Iis\Flat\Session\SessionInterface;

class PostPersist extends Event
{

    public function __construct(private Entity $subject,private SessionInterface $session)
    {
    }

    public function getSession(): SessionInterface
    {
       return $this->session;
    }
    public function getSubject() : Entity
    {
        return $this->subject;
    }

}