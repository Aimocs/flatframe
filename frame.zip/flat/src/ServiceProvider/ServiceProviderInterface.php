<?php

namespace Aimocs\Iis\Flat\ServiceProvider;

interface ServiceProviderInterface
{

    public function register():void;

}