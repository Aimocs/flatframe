<?php

namespace Aimocs\Iis\Flat\TemplateEngine;

use Aimocs\Iis\Flat\Session\SessionInterface;

class Engine implements TemplateEngineInterface
{
    private string $templatesDirectory;
    private string $cacheDirectory;

    private SessionInterface $session;

    public function __construct(string $templatesDirectory, SessionInterface $session)
    {
        $this->templatesDirectory = rtrim($templatesDirectory, DIRECTORY_SEPARATOR);
        $this->cacheDirectory = dirname($templatesDirectory) . "/cache";
        $this->session = $session;

        // Ensure cache directory exists
        if (!is_dir($this->cacheDirectory) && !mkdir($this->cacheDirectory, 0777, true)) {
            throw new \RuntimeException("Failed to create cache directory: {$this->cacheDirectory}");
        }
    }

    public function render(string $path, array $data): string
    {
        $templatePath = $this->templatesDirectory . DIRECTORY_SEPARATOR . $path . ".yolo";
        //need to replace cache with a proper naem
        $cachedPath = $this->cacheDirectory . DIRECTORY_SEPARATOR . "cache" . '.php';

        // Ensure the template file exists and is readable
        if (!file_exists($templatePath) || !is_readable($templatePath)) {
            throw new \RuntimeException("Template not found: {$templatePath}");
        }

        // Compile the template if the cache doesn't exist or is outdated
            $processedTemplate = $this->processTemplate($templatePath);
            file_put_contents($cachedPath, $processedTemplate);

        // Extract variables in a controlled environment and include the cached file
        return $this->renderTemplate($cachedPath, $data);
    }

    private function processTemplate(string $templatePath): string
    {
        $content = file_get_contents($templatePath);

        // Handle {% extends %} with relative path resolution
        $content = $this->processExtends($content, $templatePath);

        // Replace {{ }} with PHP echo statements
        $content = preg_replace('/{{\s*(.+?)\s*}}/', '<?php echo htmlspecialchars($1, ENT_QUOTES, "UTF-8"); ?>', $content);

        // Replace {% %} with PHP code blocks
        $content = preg_replace('/{%\s*(.+?)\s*%}/', '<?php $1 ?>', $content);

        return $content;
    }

    private function processExtends(string $content, string $childTemplatePath): string
    {
        if (preg_match('/{%\s*extends\s+(.+?)\s*%}/', $content, $matches)) {
            $parentTemplate = trim($matches[1], "'\"");

            // Resolve parent template path relative to child template's directory
            $childDirectory = dirname($childTemplatePath);
            $parentPath = realpath($this->templatesDirectory.$parentTemplate);


            if (!$parentPath || !file_exists($parentPath)) {
                throw new \RuntimeException("Parent template not found: {$parentTemplate}");
            }

            $parentContent = file_get_contents($parentPath);
            $contentBlocks = $this->extractBlocks($content);

            // Merge blocks from child into the parent template
            return $this->mergeBlocks($parentContent, $contentBlocks);
        }

        return $content;
    }

    private function extractBlocks(string $content): array
    {
        $blocks = [];
        if (preg_match_all('/{%\s*block\s+(\w+)\s*%}(.+?){%\s*endblock\s*%}/s', $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $blocks[$match[1]] = $match[2];
            }
        }
        return $blocks;
    }

    private function mergeBlocks(string $parentContent, array $childBlocks): string
    {
        return preg_replace_callback(
            '/{%\s*block\s+(\w+)\s*%}(.+?){%\s*endblock\s*%}/s',
            function ($matches) use ($childBlocks) {
                $blockName = $matches[1];
                $parentBlock = $matches[2];
                return $childBlocks[$blockName] ?? $parentBlock;
            },
            $parentContent
        );
    }

    private function renderTemplate(string $cachedPath, array $data): string
    {
        //add session to the scope so i don't have to write $this->
        $session = $this->session;
        // Isolate the variable scope
        extract($this->escapeData($data), EXTR_SKIP);

        // Start output buffering
        ob_start();

        try {
            include $cachedPath; // Include the preprocessed template
        } catch (\Throwable $e) {
            ob_end_clean(); // Discard buffer on error
            throw new \RuntimeException("Error rendering template: " . $e->getMessage(), 0, $e);
        }

        return ob_get_clean(); // Get and clean the output buffer
    }

    private function escapeData(array $data): array
    {
        // Automatically escape data to prevent XSS
        return array_map(function ($value) {
            return is_string($value) ? htmlspecialchars($value, ENT_QUOTES, 'UTF-8') : $value;
        }, $data);
    }
}
