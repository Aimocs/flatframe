<?php

namespace Aimocs\Iis\Flat\Authentication;

interface AuthRepoInterface
{
    public function findByUsername(string $username): ?AuthUserInterface;

}