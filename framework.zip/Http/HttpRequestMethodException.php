<?php

namespace Aimocs\Iis\Flat\Http;

class HttpRequestMethodException extends HttpException
{

}