<?php

namespace Aimocs\Iis\Flat\Routing;

use Aimocs\Iis\Flat\Http\Request;

interface RouterInterface
{

    public function dispatch(Request $request);

}