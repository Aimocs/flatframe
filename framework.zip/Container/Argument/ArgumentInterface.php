<?php

namespace Aimocs\Iis\Flat\Container\Argument;

interface ArgumentInterface
{
    public function getValue();
}